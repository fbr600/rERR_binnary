library(testthat)
library(rERR)

test_check("rERR")
